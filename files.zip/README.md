# Fastish v2.0 — Telegram Web App

> Find shifts. Hire fast. The gig marketplace for short-term jobs.

## 📁 Files
```
index.html  — App shell + all pages
styles.css  — Dark theme styles
app.js      — All logic, data, navigation
README.md   — This file
```

## 🚀 Deploy to GitHub Pages (HTTPS)

1. Create GitHub repo e.g. `fastish-app`
2. Upload all 3 files to root
3. Go to **Settings → Pages → Source → main / root → Save**
4. App goes live at `https://YOUR_USERNAME.github.io/fastish-app/`
5. In [@BotFather](https://t.me/BotFather): `/newbot` → `/setmenubutton` → paste URL

## 🛡️ Admin Setup

Open `app.js` and replace the two IDs at the top:
```js
const ADMIN_IDS = [
  123456789,   // ← Your Telegram numeric ID
  987654321    // ← Your friend's Telegram numeric ID
];
```

To find your Telegram ID, message [@userinfobot](https://t.me/userinfobot).
Admins see a 🛡️ button in the header that opens the Admin Panel.

## ✅ Features in v2.0

| Feature | Status |
|---|---|
| Telegram user profile (name, avatar) | ✅ |
| Browse & search job listings | ✅ |
| Category filters + sort | ✅ |
| Post a job form | ✅ |
| **Live Map (Leaflet)** for Nearby Jobs | ✅ |
| **Identity Verification** (passport + selfie, 1:1 policy) | ✅ |
| Verification queue for admins | ✅ |
| **Penalty system** (warning / ban / fine) | ✅ |
| No-show policy displayed in job modal | ✅ |
| **Admin Panel** (users, verify queue, penalties, jobs) | ✅ |
| **Two admin accounts** by Telegram ID | ✅ |
| Leaderboard (Workers & Employers) | ✅ |
| Referral system + share via Telegram | ✅ |
| Points system | ✅ |
| Earnings balance card | ✅ |
| Dark minimalist design | ✅ |
| Mobile-first, Telegram-native feel | ✅ |

## 🗺️ Map Notes
- Uses OpenStreetMap + Leaflet (free, no API key needed)
- Automatically falls back to Tashkent demo if location denied
- Job pins shown on map with popup details

## ⚠️ Penalty System Logic
| Offense | Penalty |
|---|---|
| 1st no-show | Warning |
| 2nd no-show | 7-day ban + $5 fine |
| 3rd no-show | 15-day ban + $15 fine |
| 4+ no-shows | Permanent ban review |

Admins can issue custom penalties or lift existing ones from the Admin Panel.

## 🔧 Connect Real Backend
Replace `MOCK_JOBS`, `ADMIN_USERS` etc. with `fetch()` calls to your API.
