// =================== FASTISH APP.JS v2.0 ===================

// ---- ADMIN TELEGRAM IDs — replace with yours ----
const ADMIN_IDS = [
  123456789,   // ← Replace with your Telegram numeric ID
  987654321    // ← Replace with your friend's Telegram numeric ID
];

// ---- STATE ----
const state = {
  user: {
    id: null, name: 'Guest', username: '', photo: null,
    points: 320, balance: 126.50,
    verifyStatus: 'unverified', // 'unverified' | 'pending' | 'approved' | 'rejected'
    penaltyStatus: null, // null | { type, reason, until, fine }
    isAdmin: false,
    noShowCount: 0,
  },
  currentPage: 'home',
  activeFilter: 'all',
  activeSort: 'recent',
  workerCount: 1,
  lboardMode: 'workers',
  adminTab: 'users',
  savedJobs: new Set(),
  mapInstance: null,
  userLat: null, userLng: null,
};

// ---- MOCK DATA ----
const MOCK_JOBS = [
  { id:1, title:'Barista – Weekend Shift', category:'food', pay:'$18/hr', payNum:18, duration:'6 hrs', date:'Sat Apr 5', time:'8:00 AM', location:'Downtown Café, Main St', lat:41.302, lng:69.242, distance:'0.4 km', slots:2, desc:'We need an experienced barista for our busy weekend morning shift. Must be comfortable with espresso machines and high-volume service.', employer:'Brew Co.', rating:4.8, urgent:true },
  { id:2, title:'Retail Assistant', category:'retail', pay:'$15/hr', payNum:15, duration:'4 hrs', date:'Sun Apr 6', time:'2:00 PM', location:'City Mall, Level 2', lat:41.299, lng:69.247, distance:'1.2 km', slots:1, desc:'Help customers on the floor, restock shelves, and manage fitting rooms. No experience required — will train.', employer:'StyleZone', rating:4.5, urgent:false },
  { id:3, title:'Food Delivery Rider', category:'delivery', pay:'$20/hr', payNum:20, duration:'5 hrs', date:'Mon Apr 7', time:'5:00 PM', location:'Central Kitchen Hub', lat:41.305, lng:69.255, distance:'2.1 km', slots:4, desc:'Deliver food orders across the city using the provided e-bike. Must have a valid license and phone.', employer:'QuickBite', rating:4.7, urgent:true },
  { id:4, title:'Office Deep Clean', category:'cleaning', pay:'$22/hr', payNum:22, duration:'3 hrs', date:'Fri Apr 4', time:'9:00 PM', location:'Business District, Tower A', lat:41.295, lng:69.238, distance:'3.0 km', slots:2, desc:'Evening deep clean of a corporate office. Equipment provided. Reliable and detail-oriented preferred.', employer:'CleanPro', rating:4.6, urgent:false },
  { id:5, title:'Event Staff – Tech Expo', category:'events', pay:'$16/hr', payNum:16, duration:'8 hrs', date:'Sat Apr 5', time:'10:00 AM', location:'Convention Center', lat:41.308, lng:69.262, distance:'1.8 km', slots:6, desc:'Help manage crowd flow, direct attendees, scan badges, and assist with setup/teardown at a large tech expo.', employer:'EventsWorld', rating:4.4, urgent:false },
  { id:6, title:'Data Entry Operator', category:'tech', pay:'$14/hr', payNum:14, duration:'4 hrs', date:'Mon Apr 7', time:'10:00 AM', location:'Remote', lat:null, lng:null, distance:'Remote', slots:3, desc:'Enter and verify product listings in our database. Fast typer with attention to detail preferred. Work from home.', employer:'DataCorp', rating:4.2, urgent:false },
  { id:7, title:'Warehouse Packer', category:'retail', pay:'$16/hr', payNum:16, duration:'6 hrs', date:'Wed Apr 9', time:'7:00 AM', location:'Logistics Park, Gate 4', lat:41.288, lng:69.268, distance:'4.5 km', slots:8, desc:'Pick and pack orders at a busy e-commerce warehouse. Must stand for long periods. Equipment provided.', employer:'FastShip', rating:4.3, urgent:true },
  { id:8, title:'Brand Promoter', category:'events', pay:'$15/hr', payNum:15, duration:'4 hrs', date:'Thu Apr 10', time:'12:00 PM', location:'City Square', lat:41.300, lng:69.240, distance:'0.9 km', slots:3, desc:'Promote a new energy drink brand at a public activation. Friendly and outgoing personality needed.', employer:'BuzzBrands', rating:4.5, urgent:false },
];

const MOCK_LEADERBOARD_WORKERS = [
  { name:'Alex K.', pts:4820, shifts:38, avatar:'🧑' },
  { name:'Mira S.', pts:4200, shifts:34, avatar:'👩' },
  { name:'John T.', pts:3950, shifts:31, avatar:'🧔' },
  { name:'Sofia L.', pts:3410, shifts:27, avatar:'👱‍♀️' },
  { name:'Omar R.', pts:2990, shifts:24, avatar:'👨' },
  { name:'Priya M.', pts:2540, shifts:21, avatar:'👩‍🦱' },
  { name:'Leo B.', pts:2100, shifts:17, avatar:'🧑‍🦰' },
  { name:'Nina V.', pts:1800, shifts:15, avatar:'👩‍🦳' },
];
const MOCK_LEADERBOARD_EMPLOYERS = [
  { name:'QuickBite', pts:9200, jobs:54, avatar:'🍔' },
  { name:'CleanPro', pts:7400, jobs:43, avatar:'🧹' },
  { name:'EventsWorld', pts:6800, jobs:39, avatar:'🎪' },
  { name:'StyleZone', pts:5500, jobs:31, avatar:'🛍️' },
  { name:'DataCorp', pts:4200, jobs:25, avatar:'💻' },
  { name:'FastShip', pts:3800, jobs:22, avatar:'📦' },
];
const MOCK_REFERRALS = [
  { name:'Sara J.', pts:100, avatar:'👩' },
  { name:'Mike D.', pts:100, avatar:'👨' },
];

// Admin mock data
const ADMIN_USERS = [
  { id:1, name:'Alex Kim', username:'alexkim', verifyStatus:'approved', penaltyStatus:null, noShows:0, shifts:38, avatar:'🧑' },
  { id:2, name:'Mira Sole', username:'mira_s', verifyStatus:'pending', penaltyStatus:null, noShows:1, shifts:12, avatar:'👩' },
  { id:3, name:'John Trent', username:'jtrent', verifyStatus:'approved', penaltyStatus:{type:'ban',until:'Apr 20, 2026',reason:'No-show x2'}, noShows:2, shifts:8, avatar:'🧔' },
  { id:4, name:'Sofia Lee', username:'soflee', verifyStatus:'unverified', penaltyStatus:null, noShows:0, shifts:0, avatar:'👱‍♀️' },
  { id:5, name:'Omar Rashid', username:'omar_r', verifyStatus:'approved', penaltyStatus:{type:'fine',amount:'$10',reason:'Late cancellation'}, noShows:1, shifts:24, avatar:'👨' },
  { id:6, name:'Priya Mehta', username:'priya_m', verifyStatus:'rejected', penaltyStatus:null, noShows:0, shifts:0, avatar:'👩‍🦱' },
];
const ADMIN_VERIFY_QUEUE = [
  { id:101, name:'Sam Parker', username:'samparker', submitted:'Mar 28, 2026', passportId:'UZ****4521', selfie:true },
  { id:102, name:'Lena Morel', username:'lena_m', submitted:'Mar 29, 2026', passportId:'UZ****8834', selfie:true },
  { id:103, name:'Ivan Petrov', username:'ipetrov', submitted:'Mar 30, 2026', passportId:'UZ****2219', selfie:false },
];
const ADMIN_PENALTIES = [
  { id:201, user:'John Trent', type:'Ban 15 days', reason:'No-show x2', date:'Apr 5, 2026', active:true, until:'Apr 20, 2026' },
  { id:202, user:'Omar Rashid', type:'Fine $10', reason:'Late cancellation', date:'Apr 3, 2026', active:true, until:'—' },
  { id:203, user:'Tom Chen', type:'Warning', reason:'First no-show', date:'Mar 25, 2026', active:false, until:'—' },
  { id:204, user:'Nina V.', type:'Ban 7 days', reason:'False experience claim', date:'Mar 20, 2026', active:false, until:'—' },
];

const DAYS = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const CAT_LABELS = { food:'🍔 Food', retail:'🛍️ Retail', delivery:'🚴 Delivery', cleaning:'🧹 Cleaning', events:'🎪 Events', tech:'💻 Tech', other:'📦 Other' };

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
  initTelegram();
  setTimeout(launchApp, 1500);
});

function initTelegram() {
  if (window.Telegram?.WebApp) {
    const tg = window.Telegram.WebApp;
    tg.ready(); tg.expand();
    try { tg.setHeaderColor('#0a0a0f'); tg.setBackgroundColor('#0a0a0f'); } catch(e) {}
    const user = tg.initDataUnsafe?.user;
    if (user) {
      state.user.id = user.id;
      state.user.name = user.first_name + (user.last_name ? ' ' + user.last_name : '');
      state.user.username = user.username || '';
      state.user.photo = user.photo_url || null;
      state.user.isAdmin = ADMIN_IDS.includes(user.id);
    }
  }
  // For demo — uncomment to preview as admin:
  // state.user.isAdmin = true;
  // state.user.id = ADMIN_IDS[0];
}

function launchApp() {
  const splash = document.getElementById('splash');
  splash.classList.add('fade-out');
  setTimeout(() => {
    splash.style.display = 'none';
    document.getElementById('app').classList.remove('hidden');
    renderUser();
    renderHome();
    renderFind();
    renderLeaderboard();
    renderReferral();
    renderVerify();
    renderProfile();
    buildAvailGrid();
    renderAdmin();
    // Show admin button for admins
    if (state.user.isAdmin) document.getElementById('adminBtn').style.display = 'flex';
    // Hide verify banner if already verified
    if (state.user.verifyStatus === 'approved') document.getElementById('verifyBanner').style.display = 'none';
  }, 500);
}

// ---- RENDER USER ----
function renderUser() {
  const u = state.user;
  document.getElementById('userName').textContent = u.name;
  document.getElementById('userSub').textContent = u.username ? '@' + u.username : (u.isAdmin ? '🛡️ Admin' : 'Worker');
  document.getElementById('balanceAmount').textContent = '$' + u.balance.toFixed(2);
  document.getElementById('userPoints').textContent = u.points;
  document.getElementById('profileName').textContent = u.name;
  document.getElementById('profileBadge').textContent = '⚡ ' + u.points + ' pts';

  // Verify status badges
  const statusBadge = document.getElementById('verifyStatusBadge');
  const profileVBadge = document.getElementById('profileVerifyBadge');
  const badgeMap = {
    unverified: ['badge-unverified','⏳ Unverified'],
    pending:    ['badge-unverified','🕐 Under Review'],
    approved:   ['badge-verified','✅ Verified'],
    rejected:   ['badge-banned','❌ Rejected'],
  };
  const [cls, txt] = badgeMap[u.verifyStatus] || badgeMap.unverified;
  [statusBadge, profileVBadge].forEach(el => { el.className = cls; el.textContent = txt; });

  // Avatar
  if (u.photo) {
    ['avatarImg','profileAvatarImg'].forEach(id => { const el=document.getElementById(id); el.src=u.photo; el.classList.remove('hidden'); });
    ['avatarFallback','profileAvatarFallback'].forEach(id => document.getElementById(id).classList.add('hidden'));
  } else {
    const initial = u.name.charAt(0).toUpperCase();
    ['avatarFallback','profileAvatarFallback'].forEach(id => { document.getElementById(id).textContent = initial; });
  }

  // Penalty banner
  if (u.penaltyStatus) {
    const pb = document.getElementById('penaltyBanner');
    pb.classList.remove('hidden');
    document.getElementById('penaltyTitle').textContent = u.penaltyStatus.type === 'ban' ? '🚫 Account Banned' : '⚠️ Fine Issued';
    document.getElementById('penaltySub').textContent = u.penaltyStatus.reason + (u.penaltyStatus.until ? ' · Until ' + u.penaltyStatus.until : '');
  }
}

// ---- HOME ----
function renderHome() {
  document.getElementById('activeShiftsList').innerHTML = MOCK_JOBS.filter(j=>j.urgent).slice(0,3).map(j=>jobCardHTML(j)).join('');
  document.getElementById('recommendedList').innerHTML = MOCK_JOBS.filter(j=>!j.urgent).slice(0,3).map(j=>jobCardHTML(j)).join('');
}

// ---- JOB CARD ----
function jobCardHTML(job) {
  const saved = state.savedJobs.has(job.id);
  return `
  <div class="job-card" onclick="openJobModal(${job.id})">
    <div class="job-card-top">
      <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
        <span class="job-cat-tag">${CAT_LABELS[job.category]||job.category}</span>
        ${job.urgent ? '<span class="urgent-tag">🔥 Urgent</span>' : ''}
      </div>
      <span class="job-pay">${job.pay}</span>
    </div>
    <div class="job-title">${job.title}</div>
    <div class="job-meta">
      <span>📅 ${job.date}</span>
      <span>⏱ ${job.duration}</span>
      <span>📍 ${job.distance}</span>
      <span>👥 ${job.slots} slots</span>
    </div>
    <div class="job-footer">
      <button class="apply-btn" onclick="event.stopPropagation();applyJob(${job.id})">Apply Now</button>
      <button class="save-btn ${saved?'saved':''}" onclick="event.stopPropagation();toggleSave(${job.id},this)">🔖</button>
    </div>
  </div>`;
}

// ---- FIND ----
function renderFind() { filterJobs(); }

function filterJobs() {
  const q = (document.getElementById('searchInput')?.value||'').toLowerCase();
  let jobs = MOCK_JOBS.filter(j =>
    (state.activeFilter==='all'||j.category===state.activeFilter) &&
    (j.title.toLowerCase().includes(q)||j.location.toLowerCase().includes(q))
  );
  if (state.activeSort==='pay') jobs.sort((a,b)=>b.payNum-a.payNum);
  if (state.activeSort==='distance') jobs.sort((a,b)=>(a.distance==='Remote'?99:parseFloat(a.distance))-(b.distance==='Remote'?99:parseFloat(b.distance)));
  const el = document.getElementById('findJobsList');
  if (el) el.innerHTML = jobs.length ? jobs.map(j=>jobCardHTML(j)).join('') : '<p style="text-align:center;color:var(--text2);padding:32px 0">No shifts found</p>';
}

function setFilter(cat, btn) {
  state.activeFilter = cat;
  document.querySelectorAll('.filter-chip').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); filterJobs();
}
function setSort(s, btn) {
  state.activeSort = s;
  document.querySelectorAll('.sort-chip').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active'); filterJobs();
}

// ---- MAP / NEARBY ----
function initMap() {
  if (!navigator.geolocation) { showToast('⚠️ Geolocation not supported'); return; }
  showToast('📍 Getting your location...');
  navigator.geolocation.getCurrentPosition(pos => {
    state.userLat = pos.coords.latitude;
    state.userLng = pos.coords.longitude;
    document.getElementById('mapEnableWrap').classList.add('hidden');
    const mc = document.getElementById('mapContainer');
    mc.classList.remove('hidden');
    document.getElementById('nearbyJobsSection').classList.remove('hidden');
    document.getElementById('nearbyLocation').textContent = '📍 Near your location';
    buildMap(state.userLat, state.userLng);
  }, () => {
    // fallback to Tashkent for demo
    state.userLat = 41.299; state.userLng = 69.240;
    document.getElementById('mapEnableWrap').classList.add('hidden');
    document.getElementById('mapContainer').classList.remove('hidden');
    document.getElementById('nearbyJobsSection').classList.remove('hidden');
    document.getElementById('nearbyLocation').textContent = '📍 Showing demo location (Tashkent)';
    buildMap(state.userLat, state.userLng);
  });
}

function buildMap(lat, lng) {
  if (state.mapInstance) { state.mapInstance.remove(); state.mapInstance = null; }
  const map = L.map('leafletMap', { zoomControl: true, attributionControl: false }).setView([lat, lng], 14);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19 }).addTo(map);
  state.mapInstance = map;

  // User marker
  const userIcon = L.divIcon({ html:'<div style="width:16px;height:16px;background:#e8ff47;border-radius:50%;border:3px solid #0a0a0f;box-shadow:0 0 0 3px rgba(232,255,71,.4)"></div>', iconSize:[16,16], iconAnchor:[8,8], className:'' });
  L.marker([lat,lng],{icon:userIcon}).addTo(map).bindPopup('<b>You are here</b>');

  // Job markers
  const jobIcon = L.divIcon({ html:'<div style="background:#e8ff47;color:#0a0a0f;font-weight:800;font-size:10px;padding:4px 7px;border-radius:8px;white-space:nowrap;font-family:Syne,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.4)">SHIFT</div>', className:'', iconAnchor:[25,15] });
  const nearbyJobs = MOCK_JOBS.filter(j=>j.lat&&j.lng);
  nearbyJobs.forEach(job => {
    L.marker([job.lat,job.lng],{icon:jobIcon}).addTo(map).bindPopup(`<b>${job.title}</b><br>${job.pay} · ${job.duration}<br><small>${job.location}</small>`);
  });

  // Nearby list
  const nl = document.getElementById('nearbyJobsList');
  document.getElementById('nearbyCountLabel').textContent = `${nearbyJobs.length} Shifts Nearby`;
  nl.innerHTML = nearbyJobs.map(j=>jobCardHTML(j)).join('');
}

// ---- POST JOB ----
let _workerCount = 1;
function changeCount(d) { _workerCount = Math.max(1,Math.min(20,_workerCount+d)); document.getElementById('workerCount').textContent = _workerCount; }
function submitJob() {
  const title = document.getElementById('jobTitle').value.trim();
  const cat = document.getElementById('jobCategory').value;
  const pay = document.getElementById('jobPay').value.trim();
  const loc = document.getElementById('jobLocation').value.trim();
  if (!title||!cat||!pay||!loc) { showToast('⚠️ Please fill in required fields'); return; }
  showToast('🎉 Job posted successfully!');
  ['jobTitle','jobPay','jobDuration','jobLocation','jobDesc'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('jobCategory').value=''; _workerCount=1; document.getElementById('workerCount').textContent=1;
  state.user.points+=20; updatePoints();
  setTimeout(()=>navigate('find'),1500);
}

// ---- LEADERBOARD ----
function renderLeaderboard() {
  const data = state.lboardMode==='workers' ? MOCK_LEADERBOARD_WORKERS : MOCK_LEADERBOARD_EMPLOYERS;
  document.getElementById('lboardList').innerHTML = data.map((item,i) => {
    const rankEmoji = i===0?'🥇':i===1?'🥈':i===2?'🥉':(i+1);
    const sub = state.lboardMode==='workers' ? `${item.shifts} shifts` : `${item.jobs} jobs`;
    return `<div class="lboard-item">
      <div class="lboard-rank ${i<3?'top':''}">${rankEmoji}</div>
      <div class="lboard-avatar">${item.avatar}</div>
      <div class="lboard-info"><div class="lboard-name">${item.name}</div><div class="lboard-sub">${sub}</div></div>
      <div class="lboard-pts">⚡ ${item.pts.toLocaleString()}</div>
    </div>`;
  }).join('');
}
function setLboard(mode,btn) { state.lboardMode=mode; document.querySelectorAll('.lboard-tab').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); renderLeaderboard(); }

// ---- REFERRAL ----
function renderReferral() {
  const id = state.user.id||'demo123';
  document.getElementById('refLink').textContent = `https://t.me/FastishBot?start=ref_${id}`;
  document.getElementById('refCount').textContent = MOCK_REFERRALS.length;
  document.getElementById('refPoints').textContent = MOCK_REFERRALS.length*100;
  document.getElementById('refActive').textContent = MOCK_REFERRALS.length;
  document.getElementById('referralList').innerHTML = MOCK_REFERRALS.map(r=>`
    <div class="referral-item">
      <div class="ref-user-avatar">${r.avatar}</div>
      <div class="ref-user-name">${r.name}</div>
      <div class="ref-user-pts">+${r.pts} pts</div>
    </div>`).join('');
}
function copyRefLink() {
  const link = document.getElementById('refLink').textContent;
  navigator.clipboard?.writeText(link).then(()=>showToast('🔗 Link copied!')).catch(()=>showToast('Copy: '+link));
}
function shareRefLink() {
  const id = state.user.id||'demo123';
  const link = `https://t.me/FastishBot?start=ref_${id}`;
  if (window.Telegram?.WebApp) window.Telegram.WebApp.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent('🚀 Join Fastish — find shifts & earn fast!')}`);
  else navigator.clipboard?.writeText(link).then(()=>showToast('Link copied!'));
}

// ---- VERIFY PAGE ----
function renderVerify() {
  const el = document.getElementById('verifyContent');
  if (!el) return;
  const s = state.user.verifyStatus;

  if (s === 'approved') {
    el.innerHTML = `
      <div class="verify-status-card approved">
        <div class="verify-status-icon">✅</div>
        <div class="verify-status-title" style="color:var(--success)">Identity Verified</div>
        <div class="verify-status-desc">Your passport has been verified. You can apply for any shift on Fastish. One passport is linked to your account permanently.</div>
      </div>`;
  } else if (s === 'pending') {
    el.innerHTML = `
      <div class="verify-status-card pending">
        <div class="verify-status-icon">🕐</div>
        <div class="verify-status-title" style="color:var(--warn)">Under Review</div>
        <div class="verify-status-desc">Your documents have been submitted and are being reviewed by our team. This usually takes 1–24 hours. You'll be notified via Telegram.</div>
      </div>`;
  } else if (s === 'rejected') {
    el.innerHTML = `
      <div class="verify-status-card rejected">
        <div class="verify-status-icon">❌</div>
        <div class="verify-status-title" style="color:var(--danger)">Verification Rejected</div>
        <div class="verify-status-desc">Your documents were rejected. Please resubmit with a clearer photo of your passport and a matching selfie.</div>
      </div>
      <div id="verifyFormArea"></div>`;
    renderVerifyForm(document.getElementById('verifyFormArea'));
  } else {
    el.innerHTML = '<div id="verifyFormArea"></div>';
    renderVerifyForm(document.getElementById('verifyFormArea'));
  }
}

function renderVerifyForm(container) {
  container.innerHTML = `
    <div class="verify-step">
      <div class="verify-step-icon">🪪</div>
      <div class="verify-step-title">Step 1 — Upload Passport</div>
      <div class="verify-step-desc">Photo of the ID page clearly showing your full name and date of birth. Only one passport can be linked per account — this cannot be changed later.</div>
      <div class="verify-upload-box" id="passportBox" onclick="fakeUpload('passportBox','passport')">
        📂 Tap to upload passport photo
      </div>
    </div>
    <div class="verify-step">
      <div class="verify-step-icon">🤳</div>
      <div class="verify-step-title">Step 2 — Take a Selfie</div>
      <div class="verify-step-desc">A clear selfie of your face. Must match the passport photo. This confirms you're the real person behind the account.</div>
      <div class="verify-upload-box" id="selfieBox" onclick="fakeUpload('selfieBox','selfie')">
        📸 Tap to take or upload selfie
      </div>
    </div>
    <div class="verify-step" style="background:var(--warn-dim);border-color:rgba(255,170,44,.25)">
      <div style="font-size:1.2rem;margin-bottom:6px">📜</div>
      <div class="verify-step-title" style="font-size:.88rem;color:var(--warn)">1 Passport = 1 Account Policy</div>
      <div class="verify-step-desc">By submitting, you agree that your passport can only be used for one Fastish account. Duplicate accounts will be permanently banned.</div>
    </div>
    <button class="primary-btn full" id="submitVerifyBtn" onclick="submitVerification()">Submit for Verification →</button>`;
}

const _verifyUploaded = { passport: false, selfie: false };
function fakeUpload(boxId, type) {
  _verifyUploaded[type] = true;
  const box = document.getElementById(boxId);
  box.classList.add('has-file');
  box.textContent = type === 'passport' ? '✅ Passport photo uploaded' : '✅ Selfie uploaded';
}
function submitVerification() {
  if (!_verifyUploaded.passport || !_verifyUploaded.selfie) {
    showToast('⚠️ Please upload both documents');
    return;
  }
  state.user.verifyStatus = 'pending';
  renderVerify();
  renderUser();
  showToast('📨 Documents submitted for review!');
  document.getElementById('verifyBanner').style.display = 'none';
  haptic('medium');
}

// ---- PROFILE ----
function renderProfile() {
  document.getElementById('shiftsCompleted').textContent = 7;
  document.getElementById('totalEarned').textContent = '$' + state.user.balance.toFixed(0);
  document.getElementById('workerRating').textContent = '4.8⭐';
  document.getElementById('workerStreak').textContent = '3🔥';
  document.getElementById('jobsPosted').textContent = 2;
  document.getElementById('totalHired').textContent = 8;
  document.getElementById('employerRating').textContent = '4.9⭐';
  document.getElementById('responseRate').textContent = '96%';

  const hist = document.getElementById('penaltyHistory');
  if (state.user.penaltyStatus) {
    const p = state.user.penaltyStatus;
    hist.innerHTML = `
      <div class="penalty-item active-penalty">
        <div class="penalty-item-header"><span class="penalty-type">${p.type==='ban'?'🚫 Temporary Ban':'⚠️ Fine Issued'}</span><span class="penalty-date">Active</span></div>
        <div class="penalty-reason">${p.reason}</div>
        ${p.until ? `<div class="penalty-countdown">Lifts: ${p.until}</div>` : ''}
        ${p.fine ? `<div class="penalty-countdown">Fine: ${p.fine}</div>` : ''}
      </div>`;
  } else {
    hist.innerHTML = '<div class="no-penalty">✅ No penalties — great record!</div>';
  }
}

function setProfileTab(tab, btn) {
  document.querySelectorAll('.profile-tab').forEach(b=>b.classList.remove('active')); btn.classList.add('active');
  document.getElementById('workerTab').classList.toggle('hidden', tab!=='worker');
  document.getElementById('employerTab').classList.toggle('hidden', tab!=='employer');
}
function toggleSkill(btn) { btn.classList.toggle('active'); }
function buildAvailGrid() {
  document.getElementById('availGrid').innerHTML = DAYS.map((d,i) => `
    <div class="avail-day ${[0,1,4].includes(i)?'active':''}" onclick="this.classList.toggle('active')">
      <span class="avail-day-name">${d}</span>
    </div>`).join('');
}

// ---- PENALTY MODAL ----
function openPenaltyModal() {
  const p = state.user.penaltyStatus;
  if (!p) return;
  document.getElementById('penaltyModalContent').innerHTML = `
    <h3 style="font-family:var(--font-d);font-weight:800;color:var(--danger);font-size:1.2rem;margin-bottom:6px">${p.type==='ban'?'🚫 Account Banned':'⚠️ Fine Issued'}</h3>
    <p style="color:var(--text2);font-size:.85rem;margin-bottom:18px;line-height:1.6">${p.reason}</p>
    ${p.until?`<div style="background:var(--bg3);border-radius:10px;padding:12px 14px;margin-bottom:14px"><div style="font-size:.72rem;color:var(--text2);margin-bottom:3px">RESTRICTION LIFTS</div><div style="font-family:var(--font-d);font-weight:700">${p.until}</div></div>`:''}
    ${p.fine?`<div style="background:var(--danger-dim);border:1px solid rgba(255,79,106,.3);border-radius:10px;padding:12px 14px;margin-bottom:14px"><div style="font-size:.72rem;color:var(--danger);margin-bottom:3px">FINE AMOUNT</div><div style="font-family:var(--font-d);font-weight:700;color:var(--danger)">${p.fine}</div></div>`:''}
    <div style="background:var(--bg3);border-radius:10px;padding:14px;margin-bottom:18px;font-size:.81rem;color:var(--text2);line-height:1.6">
      <b style="color:var(--text)">Fastish No-Show Policy</b><br><br>
      • 1st no-show: Warning issued<br>
      • 2nd no-show: 7-day ban + $5 fine<br>
      • 3rd no-show: 15-day ban + $15 fine<br>
      • 4+ no-shows: Permanent ban review<br><br>
      To appeal this decision, contact <b style="color:var(--accent)">@FastishSupport</b>
    </div>
    <button class="secondary-btn full" onclick="closeModal('penaltyModal')">Close</button>`;
  document.getElementById('penaltyModal').classList.remove('hidden');
  document.getElementById('penaltyModal').addEventListener('click', e => { if(e.target===document.getElementById('penaltyModal')) closeModal('penaltyModal'); }, { once:true });
}

// ---- JOB MODAL ----
function openJobModal(id) {
  const job = MOCK_JOBS.find(j=>j.id===id);
  if (!job) return;

  const blockApply = state.user.penaltyStatus?.type === 'ban';
  const needsVerify = state.user.verifyStatus !== 'approved';

  document.getElementById('modalContent').innerHTML = `
    <div class="modal-job-pay">${job.pay}</div>
    <div class="modal-job-title">${job.title}</div>
    <div class="modal-meta-list">
      <div class="modal-meta-row"><span class="modal-meta-icon">🏢</span>${job.employer} · ⭐ ${job.rating}</div>
      <div class="modal-meta-row"><span class="modal-meta-icon">📅</span>${job.date} at ${job.time}</div>
      <div class="modal-meta-row"><span class="modal-meta-icon">⏱</span>${job.duration}</div>
      <div class="modal-meta-row"><span class="modal-meta-icon">📍</span>${job.location} (${job.distance})</div>
      <div class="modal-meta-row"><span class="modal-meta-icon">👥</span>${job.slots} spots available</div>
    </div>
    <div class="modal-section">
      <div class="modal-section-title">About this shift</div>
      <div class="modal-desc">${job.desc}</div>
    </div>
    <div class="modal-section" style="background:var(--bg3);border-radius:10px;padding:12px 14px;font-size:.78rem;color:var(--text2);line-height:1.6">
      ⚠️ <b style="color:var(--text)">No-Show Policy:</b> If you accept and don't show up, you'll receive a warning. Repeated no-shows result in fines and account bans.
    </div>
    <div style="height:14px"></div>
    ${blockApply
      ? `<div style="background:var(--danger-dim);border:1px solid rgba(255,79,106,.3);border-radius:10px;padding:13px;text-align:center;color:var(--danger);font-size:.83rem;font-weight:600;margin-bottom:14px">🚫 Your account is currently banned. You cannot apply for shifts.</div>`
      : needsVerify
        ? `<button class="primary-btn full" onclick="closeModal('jobModal');navigate('verify')">🪪 Verify to Apply →</button>`
        : `<button class="primary-btn full" onclick="applyJob(${job.id});closeModal('jobModal')">Accept this Shift →</button>`
    }`;

  document.getElementById('jobModal').classList.remove('hidden');
  document.getElementById('jobModal').addEventListener('click', e=>{if(e.target===document.getElementById('jobModal'))closeModal('jobModal')},{once:true});
}

function applyJob(id) {
  const job = MOCK_JOBS.find(j=>j.id===id);
  if (!job) return;
  state.user.points += 5; updatePoints();
  showToast('✅ Applied to ' + job.title + '!');
  haptic('medium');
}

function toggleSave(id, btn) {
  if (state.savedJobs.has(id)) { state.savedJobs.delete(id); btn.classList.remove('saved'); showToast('Removed from saved'); }
  else { state.savedJobs.add(id); btn.classList.add('saved'); showToast('🔖 Saved!'); }
}

// ---- ADMIN ----
function renderAdmin() { if (state.user.isAdmin) setAdminTab('users', null); }

function setAdminTab(tab, btn) {
  state.adminTab = tab;
  document.querySelectorAll('.admin-tab').forEach(b=>b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  const c = document.getElementById('adminTabContent');
  if (!c) return;

  if (tab === 'users') {
    c.innerHTML = `
      <input class="admin-search" placeholder="🔍 Search users..." oninput="adminSearchUsers(this.value)"/>
      <div class="admin-table" id="adminUsersTable"></div>`;
    renderAdminUsers('');
  } else if (tab === 'queue') {
    c.innerHTML = `
      <div style="margin-bottom:12px;color:var(--text2);font-size:.82rem">${ADMIN_VERIFY_QUEUE.length} pending submissions</div>
      <div class="admin-table">` + ADMIN_VERIFY_QUEUE.map(u=>`
        <div class="admin-row">
          <div class="admin-row-info">
            <div class="admin-row-name">👤 ${u.name} <span style="color:var(--text2);font-weight:400">@${u.username}</span></div>
            <div class="admin-row-sub">Passport: ${u.passportId} · Selfie: ${u.selfie?'✅':'❌'} · Submitted: ${u.submitted}</div>
          </div>
          <div class="admin-row-actions">
            <button class="admin-action-btn btn-approve" onclick="adminVerifyAction(${u.id},'approve',this)">✅ Approve</button>
            <button class="admin-action-btn btn-reject" onclick="adminVerifyAction(${u.id},'reject',this)">❌ Reject</button>
          </div>
        </div>`).join('') + '</div>';
  } else if (tab === 'penalties') {
    c.innerHTML = `
      <div style="margin-bottom:12px;display:flex;justify-content:space-between;align-items:center">
        <span style="color:var(--text2);font-size:.82rem">${ADMIN_PENALTIES.filter(p=>p.active).length} active penalties</span>
        <button class="admin-action-btn btn-warn" onclick="openIssuePenaltyModal()">+ Issue Penalty</button>
      </div>
      <div class="admin-table">` + ADMIN_PENALTIES.map(p=>`
        <div class="admin-row" style="${p.active?'border-color:rgba(255,79,106,.3);':''}">
          <div class="admin-row-info">
            <div class="admin-row-name">${p.user} <span class="admin-badge ${p.active?'ab-banned':'ab-unverified'}">${p.active?'Active':'Expired'}</span></div>
            <div class="admin-row-sub">${p.type} · ${p.reason} · ${p.date}${p.until&&p.until!=='—'?' · Until '+p.until:''}</div>
          </div>
          ${p.active?`<div class="admin-row-actions"><button class="admin-action-btn btn-view" onclick="adminLiftPenalty(this)">Lift</button></div>`:''}
        </div>`).join('') + '</div>';
  } else if (tab === 'jobs') {
    c.innerHTML = `
      <div style="margin-bottom:12px;color:var(--text2);font-size:.82rem">${MOCK_JOBS.length} total jobs</div>
      <div class="admin-table">` + MOCK_JOBS.map(j=>`
        <div class="admin-row">
          <div class="admin-row-info">
            <div class="admin-row-name">${j.title}</div>
            <div class="admin-row-sub">${j.employer} · ${j.pay} · ${j.date} · ${j.slots} slots ${j.urgent?'· 🔥 Urgent':''}</div>
          </div>
          <div class="admin-row-actions">
            <button class="admin-action-btn btn-reject" onclick="showToast('Job removed')">Remove</button>
          </div>
        </div>`).join('') + '</div>';
  }
}

function renderAdminUsers(q) {
  const filtered = ADMIN_USERS.filter(u => u.name.toLowerCase().includes(q.toLowerCase()) || u.username.toLowerCase().includes(q.toLowerCase()));
  const t = document.getElementById('adminUsersTable');
  if (!t) return;
  t.innerHTML = filtered.length ? filtered.map(u=>`
    <div class="admin-row">
      <div class="admin-row-info">
        <div class="admin-row-name">${u.avatar} ${u.name} <span class="admin-badge ${u.verifyStatus==='approved'?'ab-verified':u.verifyStatus==='pending'?'ab-pending':u.penaltyStatus?'ab-banned':'ab-unverified'}">${u.verifyStatus==='approved'?'Verified':u.verifyStatus==='pending'?'Pending':u.penaltyStatus?'Penalized':'Unverified'}</span></div>
        <div class="admin-row-sub">@${u.username} · ${u.shifts} shifts · No-shows: ${u.noShows}${u.penaltyStatus?` · ⚠️ ${u.penaltyStatus.type}`:''}</div>
      </div>
      <div class="admin-row-actions">
        <button class="admin-action-btn btn-warn" onclick="openIssuePenaltyModal('${u.name}')">⚠️</button>
        <button class="admin-action-btn btn-ban" onclick="adminBanUser('${u.name}',this)">🚫</button>
      </div>
    </div>`).join('') : '<div class="admin-empty">No users found</div>';
}
function adminSearchUsers(q) { renderAdminUsers(q); }

function adminVerifyAction(id, action, btn) {
  const label = action==='approve'?'✅ Approved':'❌ Rejected';
  btn.parentElement.innerHTML = `<span style="color:${action==='approve'?'var(--success)':'var(--danger)'};font-size:.78rem;font-weight:700">${label}</span>`;
  showToast(action==='approve'?'✅ User verified!':'❌ Verification rejected');
}

function adminBanUser(name, btn) {
  btn.textContent='Banned'; btn.disabled=true;
  showToast(`🚫 ${name} has been banned`);
}
function adminLiftPenalty(btn) {
  btn.closest('.admin-row').style.opacity='.5';
  btn.textContent='Lifted'; btn.disabled=true;
  showToast('✅ Penalty lifted');
}

function openIssuePenaltyModal(userName='') {
  document.getElementById('penaltyModalContent').innerHTML = `
    <h3 style="font-family:var(--font-d);font-weight:800;font-size:1.15rem;margin-bottom:16px">⚠️ Issue Penalty</h3>
    <div class="form-group"><label class="form-label">User</label><input type="text" class="form-input" id="penaltyUser" value="${userName}" placeholder="Username or name"/></div>
    <div class="form-group"><label class="form-label">Penalty Type</label>
      <select class="form-input form-select" id="penaltyType">
        <option value="warning">⚠️ Warning (1st offense)</option>
        <option value="ban7">🚫 Ban 7 days (2nd offense)</option>
        <option value="ban15">🚫 Ban 15 days (3rd offense)</option>
        <option value="fine">💸 Fine only</option>
        <option value="permban">☠️ Permanent Ban</option>
      </select>
    </div>
    <div class="form-group"><label class="form-label">Fine Amount (optional)</label><input type="text" class="form-input" id="penaltyFine" placeholder="e.g. $10"/></div>
    <div class="form-group"><label class="form-label">Reason *</label><textarea class="form-input form-textarea" id="penaltyReason" placeholder="Describe the violation..." style="height:70px"></textarea></div>
    <div style="display:flex;gap:10px;margin-top:4px">
      <button class="danger-btn" style="flex:1" onclick="submitPenalty()">Issue Penalty</button>
      <button class="secondary-btn" style="flex:1" onclick="closeModal('penaltyModal')">Cancel</button>
    </div>`;
  document.getElementById('penaltyModal').classList.remove('hidden');
  document.getElementById('penaltyModal').addEventListener('click', e=>{if(e.target===document.getElementById('penaltyModal'))closeModal('penaltyModal')},{once:true});
}

function submitPenalty() {
  const user = document.getElementById('penaltyUser').value.trim();
  const reason = document.getElementById('penaltyReason').value.trim();
  if (!user||!reason) { showToast('⚠️ Fill in all required fields'); return; }
  closeModal('penaltyModal');
  showToast(`⚠️ Penalty issued to ${user}`);
}

// ---- NAVIGATE ----
function navigate(page) {
  if (state.currentPage === page) return;

  // Admin access guard
  if (page === 'admin' && !state.user.isAdmin) { showToast('🚫 Admin access only'); return; }

  state.currentPage = page;
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const target = document.getElementById('page-'+page);
  if (target) target.classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  document.getElementById('main').scrollTop = 0;
  haptic('selection');
}

// ---- UTILS ----
function updatePoints() {
  document.getElementById('userPoints').textContent = state.user.points;
  document.getElementById('profileBadge').textContent = '⚡ ' + state.user.points + ' pts';
}

function closeModal(id) { document.getElementById(id||'jobModal').classList.add('hidden'); }

let _toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.remove('hidden');
  clearTimeout(_toastTimer); _toastTimer = setTimeout(()=>t.classList.add('hidden'), 2600);
}

function haptic(type) {
  try {
    if (type==='selection') window.Telegram?.WebApp?.HapticFeedback?.selectionChanged();
    else window.Telegram?.WebApp?.HapticFeedback?.impactOccurred(type);
  } catch(e) {}
}
